//
//  training.swift
//  test4
//
//  Created by Afrah Saleh on 05/07/1444 AH.
//

import SwiftUI

struct training: View {
    @State var searchText = ""
    init() {
        //Use this if NavigationBarTitle is with Large Font
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        
        //Use this if NavigationBarTitle is with displayMode = .inline
        UINavigationBar.appearance().titleTextAttributes = [.foregroundColor: UIColor.white]
    }
    var body: some View {
       // NavigationView {
            ZStack {
                Color("Color")
                    .ignoresSafeArea()
                    .navigationTitle("استشاريين")
                    .navigationBarTitleDisplayMode(.inline)
                ScrollView {
                    VStack{
                        List{
                            Text("Search")
                        }
                        .searchable(text: $searchText)
                        
                    }
                    Spacer()
                    VStack {
                        Spacer()
                        ZStack{
                            RoundedRectangle(cornerRadius: 50)
                                .fill(.white)
                                .frame(width: 330, height: 140)
                                .padding(.leading, -30)
                                .padding(.top, 30)
                            Text("دكتوراه في الاقتصاد")
                                .position(x:120, y:70)
                            Text("جامعة واشنطن، الولايات")
                                .position(x:120, y:100)
                            Text("المتحدة الأمريكية")
                                .position(x:120, y:130)
                        }
                        
                        NavigationLink(destination: appointmentApply(), label:{ TrainingCardView ( title: "د. محمد سالم", image:"train_1", size: 130)}
                                    
                        )
                        .position(x: 290, y:-80)
                        .foregroundColor(.black)
                        
                        ZStack{
                            RoundedRectangle(cornerRadius: 50)
                                .fill(.white)
                                .frame(width: 330, height: 150)
                                .padding(.leading, 60)
                                .position(x:150, y:-60)
                            Text("أستاذ مساعد")
                                .position(x:120, y:-100)
                            Text("قسم اللغة العربية ")
                                .position(x:120, y:-80)
                                //.padding(.leading,-10)
                            Text("و آدابها كلية العلوم و")
                                .position(x:130, y:-60)
                               // .padding(.leading,-10)
                            Text("والدراسات الانسانية ")
                                .position(x:140, y:-40)
                                .padding(.leading,-10)
                            Text("بالأفلاج")
                                .position(x:150, y:-20)
                                .padding(.leading,-10)
                            
                        }
                        
                        NavigationLink(destination: appointmentApply(), label:{ TrainingCardView ( title: "أ.د. ساره علي", image:"train_3", size: 130)}
                        )
                        .position(x: 290, y:-220)
                        .foregroundColor(.black)
                        ZStack{
                            RoundedRectangle(cornerRadius: 50)
                                .fill(.white)
                                .frame(width: 330, height: 140)
                                .padding(.leading, 60)
                                .position(x:150, y:-210)
                            Text("أستاذ مساعد")
                                .position(x:140, y:-240)
                                .padding(.leading,-10)
                            Text("قسم التمريض")
                                .position(x:130, y:-220)
                                .padding(.leading,-0)
                            Text("كلية العلوم الطبية")
                                .position(x:130, y:-200)
                                .padding(.leading,-0)
                            Text("التطبيقية بالخرج")
                                .position(x:130, y:-180)
                                .padding(.leading,-0)
                            
                        }
                        NavigationLink(destination: appointmentApply(), label:{ TrainingCardView ( title: "أ. نوره أحمد", image:"train_2", size: 130)}
                        )
                        .position(x: 290, y:-360)
                        .foregroundColor(.black)
                        
                        
                    }
                }
       //     }
        }
    }
    struct training_Previews: PreviewProvider {
        static var previews: some View {
            training()
        }
    }
    struct TrainingCardView: View {
        var title: String
        var image: String
        let size: CGFloat
        
        var body: some View {
            VStack{
                // Image("train_1")
                Image(image)
                    .resizable()
                    .frame(width: size, height: 130 * (size/200))
                //.cornerRadius(20.0)
                Text(title)
                    .font(.title3)
                    .fontWeight(.bold)
                HStack (spacing: 2){
                    ForEach(0 ..< 5){ item in
                        Image("star")
                            .offset(x: 20)
                    }
                    Spacer()

                    
                }
                
            }
            .frame(width: size)
                .padding()
                .background(Color("Color1"))
                .cornerRadius(30)
                
            
        }
        
        
    }
}
