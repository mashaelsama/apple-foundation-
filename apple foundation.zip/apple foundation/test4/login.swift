//
//  login.swift
//  test4
//
//  Created by Afrah Saleh on 03/07/1444 AH.
//

import SwiftUI

struct login: View {
    @State var showSheet: Bool = false
    var body: some View {
       // NavigationView{
            ZStack{
                Color("back")
                    .ignoresSafeArea()
             
                Circle()
                    .fill(Color("Color6").opacity(4))
                    .frame(width: 700, height: 700)
                    .position(x: 30, y:500)
                    .blur(radius: 90)
                Circle()
                    .fill(Color("Color4"))
                    .frame(width: 1200, height: 700)
                    .position(x: 10, y:150)
                    .blur(radius: 15)
                Circle()
                    .fill(Color("Color5"))
                    .frame(width: 600, height: 700)
                    .position(x: 400, y:100)
                    .blur(radius: 10)
                
             
                RoundedRectangle(cornerRadius: 30)
                    .fill(.white.opacity(0.8))
                    .frame(width: 350, height: 350)
                    .padding(.top, 60)
                VStack(spacing: 8.0) {
                    
                    Button( action: {
                        showSheet.toggle()
                    }, label: {
                        Text(" تخطي")
                            .foregroundColor(Color.white)
                            .padding(.leading, 250.0)
                    })
                    .fullScreenCover(isPresented: $showSheet, content:{ ContentView()}
                    )
                        
                  
                           
                    Image("logo")
                        .resizable()
                        .frame(width: 250.0, height: 250.0)
                    
                    Text("مرحبا")
                        .font(.title3)
                        .fontWeight(.bold)
                        .padding(.top, -15.0)
                        .padding(.bottom, 5)
                    
                    
                    
                    Text("البريد الالكتروني:")
                        .padding(.leading, 150.0)
                        .padding(.top, 5)
                    TextField("Username", text: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/.constant("")/*@END_MENU_TOKEN@*/)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                       // .padding(.top,30)
                    /*.border(.red, width: CGFloat(wrongUsername))*/
                    Text("كلمة المرور:")
                        .padding(.leading, 180.0)
                    TextField("Password", text: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/.constant("")/*@END_MENU_TOKEN@*/)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                    
                  //  Button(""){
                        
                   // }
                  //  NavigationLink(destination: ContentView(), label: {
                        Text("تسجيل الدخول")
                   // })
                    
                    .foregroundColor(.white)
                    .frame(width: 150,height: 50)
                    .background(Color("Color"))
                    .cornerRadius(10)
                    .padding()
                    Spacer()
                    
                    
                    
                    
                }
            }
        }
   // }
    
    struct login_Previews: PreviewProvider {
        static var previews: some View {
            login()
        }
    }
}
