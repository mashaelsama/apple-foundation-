//
//  company2.swift
//  test4
//
//  Created by Farah Alarfaj on 07/07/1444 AH.
//

import SwiftUI

struct company2: View {
    @State var isDragging = false
    @State var position = CGSize.zero
    @State var present = false

    init() {
        //Use this if NavigationBarTitle is with Large Font
     
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.white]
     
     
//           //Use this if NavigationBarTitle is with displayMode = .inline
//           UINavigationBar.appearance().titleTextAttributes = [.foregroundColor: UIColor.white]
        
        
    }
    @State private var showingAlert = false
    var body: some View {
       // NavigationView {
            ZStack {
                Color("Color")
                    .ignoresSafeArea()
                    .navigationTitle("تقديم الشركات")
                    .navigationBarTitleDisplayMode(.inline)
                ScrollView {
                    Spacer()
                    VStack{
                        RoundedRectangle(cornerRadius: 40,
                                         style: .continuous)
                        .foregroundColor(Color("u"))
                        .frame(width: 400, height: 120)
                        .padding(.leading,-100)
                        .padding(.top,20)
                        
                        RoundedRectangle(cornerRadius: 40,
                                         style: .continuous)
                        .foregroundColor(Color("y"))
                        .frame(width: 400, height: 120)
                        .padding(.leading,-140)
                        .padding(.top,-128)
                        
                        RoundedRectangle(cornerRadius: 40,
                                         style: .continuous)
                        .foregroundColor(Color.white)
                        .frame(width: 400, height: 120)
                        .padding(.leading,-180)
                        .padding(.top,-135)
                        Image("com3")
                            .padding(.leading,-150)
                            .padding(.top,-180)

                        ZStack{
                            
                            RoundedRectangle(cornerRadius: 30,
                                             style: .continuous)
                            .foregroundColor(Color("y"))
                            .frame(width: 307, height: 180)
                            .padding(.leading,130)
                            .padding(.top,0)
                            
                           
                            
                        }
                        
                        
                        
                        ZStack{
                            RoundedRectangle(cornerRadius: 30,
                                             style: .continuous)
                            .foregroundColor(Color("y"))
                            .frame(width: 307, height: 180)
                            .padding(.leading,-120)
                            .padding(.top,0)
                            
                            
                        }
                        ZStack{
                            RoundedRectangle(cornerRadius: 30)
                                .fill(.white)
                                .frame(width: 300, height: 300)
                                .padding(.top,-345)
                            
                            
                            Image(systemName: "square.and.arrow.down.on.square.fill")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 70.0, height: 70.0)
                                .padding(.top,-230)
                            Button("تأكيد") {
                                /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
                                showingAlert = true
                            }
                            
                            .alert("تم ارسال السيرة الذاتية بنجاح", isPresented: $showingAlert) {
                                
                                Button("حسنا", role: .none) {
                                     present = true
                                }
                           
                            }
                            .buttonStyle(.bordered)
                            .accentColor(.white)
                            .background(Color("t"))
                            .cornerRadius(10)
                            .padding(.leading,0)
                            .padding(.top,-110)
                            
                        }
                        NavigationLink (destination: companies(), isActive: $present, label: {
                            
                        })
                         
                      
                                       }
                    
              //  }
                
              
            }}}
    
    struct company2_Previews: PreviewProvider {
        static var previews: some View {
            company2()
        }
    }
}
