//
//  profile.swift
//  test4
//
//  Created by Afrah Saleh on 03/07/1444 AH.
//

import SwiftUI

struct profile: View {
    init() {
        //Use this if NavigationBarTitle is with Large Font
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        
        //Use this if NavigationBarTitle is with displayMode = .inline
        UINavigationBar.appearance().titleTextAttributes = [.foregroundColor: UIColor.white]
    }
    
    var body: some View {
        
        
       // NavigationView {
            ZStack {
                Color("back")
                    .ignoresSafeArea()
                Circle()
                    .fill(Color("Color6").opacity(4))
                    .frame(width: 700, height: 700)
                    .position(x: 30, y:500)
                    .blur(radius: 90)
                Circle()
                    .fill(Color("Color4"))
                    .frame(width: 1200, height: 700)
                    .position(x: 10, y:150)
                    .blur(radius: 15)
                Circle()
                    .fill(Color("Color5"))
                    .frame(width: 600, height: 700)
                    .position(x: 500, y:100)
                    .blur(radius: 10)
                
                //  ScrollView{
                
                //add the body here of the page
                RoundedRectangle(cornerRadius: 30)
                    .fill(Color("b2").opacity(0.5))
                    .frame(width: 320, height: 430)
                    .position(x: 290, y: 230)
                    .padding(.top, 50)
                    .navigationTitle("حسابي")
                
                // }
                //Button(""){
                
                // }
                //VStack{
                    Text("حسابي")
                        .font(.title)
                        .foregroundColor(.white)
                        .frame(width: 250,height: 80)
                        .background(Color("button")
                            .cornerRadius(20))
                        .padding(.bottom, 300)
                   // Spacer()
                    
                    // Button(""){
                    
                    // }
                    
                    Text("تقديماتي")
                        .font(.title)
                        .foregroundColor(.white)
                        .frame(width: 250,height: 80)
                        .background(Color("button")
                            .cornerRadius(20))
                        .padding(.bottom, 110)
                   // Spacer()
                    
                    HStack{
                        //    Button(""){
                        
                        // }
                        
                       
                        
                        
                        NavigationLink(destination: login(), label: {
                            Text("تسجيل الخروج")
                                .foregroundColor(.white)
                                .multilineTextAlignment(.center)
                                .frame(width: 130,height: 80)
                                .background(Color("Color"))
                                .cornerRadius(15)
                                .padding([.top, .leading], 151.0)
                        })
                        
                        Text("حذف الحساب")
                            .foregroundColor(.white)
                            .frame(width: 130,height: 80)
                            .background(Color.red)
                            .cornerRadius(15)
                            .padding([.top, .trailing], 150)
                     //   Spacer()
                        
                    }
           
                }
            }
       // }
    //}
        struct profile_Previews: PreviewProvider {
            static var previews: some View {
                profile()
            }
        }
    }

