//
//  test4App.swift
//  test4
//
//  Created by Afrah Saleh on 02/07/1444 AH.
//

import SwiftUI

@main
struct test4App: App {
    var body: some Scene {
        WindowGroup {
            SplashView()
        }
    }
}
