//
//  appointmentApply.swift
//  test4
//
//  Created by Afrah Saleh on 03/07/1444 AH.
//

import SwiftUI
struct appointmentApply: View {
    
    init() {
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        
        UINavigationBar.appearance().titleTextAttributes = [.foregroundColor: UIColor.white]
    }
    @State private var showingAlert = false
    @State var present = false
    @State var present2 = false
    var body: some View {
       // NavigationView {
            ZStack {
                Color("Color")
                    .ignoresSafeArea()
                    .navigationTitle("طلب إستشارة")
                
                    .navigationBarTitleDisplayMode(.inline)
                Text("Placeholder")
                ScrollView{
                    VStack{
                        
                        Image("train_1")
                            .resizable()
                            .padding()
                            .frame(width: 200, height: 200)
                        ZStack{
                            RoundedRectangle(cornerRadius: 30)
                                .fill(.white)
                                .frame(width: 300, height: 300)
                            
                            Text("الولايات المتحده الامريكيه")
                            
                            Text("دكتوراه في الاقتصاد جامعه واشنطن  ")
                                .position(x:140, y:180)
                                .padding(.leading,50)
                                .padding(.top,-50)
                                .padding(.bottom,70)
                                .multilineTextAlignment(.trailing)
                            Text("د.محمد سالم ")
                                .padding(.top,-130
                                )
                                .frame(height: 9.0)
                        }
                        DatePicker(selection: /*@START_MENU_TOKEN@*/.constant(Date())/*@END_MENU_TOKEN@*/, label: { Text("احجز موعد")
                                .multilineTextAlignment(.center)
                                .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                        })
                        // .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                        .datePickerStyle(.compact)
                        
                        Button("تأكيد") {
                            /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
                            showingAlert = true
                        }
                        .alert("تم طلب الموعد بنجاح", isPresented: $showingAlert) {
                            
                            Button("الصفحة الرئيسية", role: .none) {
                              present = true
                            }
                            Button("مواعيدي", role: .none) {
                                present2 = true
                            }
                        }
                       
                        .accentColor(.white)
                        .padding()
                        .background(Color.gray)
                        .cornerRadius(10)
                        
                        NavigationLink (destination: explore(), isActive: $present, label: {
                            
                        })
                        NavigationLink (destination: appointment(), isActive: $present2, label: {
                            
                        })
                    }
                   
                }
                
           // }
         
        }
    }
}

struct appointmentApply_Previews: PreviewProvider {
    static var previews: some View {
        appointmentApply()
    }
}
