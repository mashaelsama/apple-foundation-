//
//  companies.swift
//  test4
//
//  Created by Afrah Saleh on 05/07/1444 AH.
//

import SwiftUI

struct companies: View {
    @State var searchText = ""
    init() {
        //Use this if NavigationBarTitle is with Large Font
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        
        //Use this if NavigationBarTitle is with displayMode = .inline
        UINavigationBar.appearance().titleTextAttributes = [.foregroundColor: UIColor.white]
    }
    var body: some View {
      // NavigationView {
            ZStack {
                Color("Color")
                    .ignoresSafeArea()
                    .navigationTitle("التدريب التعاوني")
                    .navigationBarTitleDisplayMode(.inline)
            Spacer()
                ScrollView {
                    
                    VStack{
                        List{
                            Text("Search")
                        }
                        .searchable(text: $searchText)
                        
                    }
                  
                    Spacer()
                    VStack {
                        Spacer()
                        ZStack{
                            RoundedRectangle(cornerRadius: 50)
                                .fill(.white)
                                .frame(width: 330, height: 140)
                                .padding(.leading, -10)
                                .padding(.top, 30)
                               // .position(x:150, y:70)
                            Text("تقوم شركة معادن ببناء  ")
                                .padding(.top, 20)
                                .padding(.leading, -120)
                            Text(" أكبر مشاريع التعدين.....")
                                .padding(.top, 80)
                                .padding(.leading, -140)
                        }
                        
                        NavigationLink(destination: company(), label:{ TrainingCardView ( image:"com2", size: 120)}
                        )
                        .position(x: 300, y:-80)
                    
                        ZStack{
                            RoundedRectangle(cornerRadius: 50)
                                .fill(.white)
                                .frame(width: 330, height: 140)
                                .padding(.leading, 60)
                                .position(x:150, y:-70)
                            Text("الشركةالسعودية للكهرباء")
                                .position(x:140, y:-80)
                            Text("شركة رائدة في ...")
                                .position(x:150, y:-50)
                        }
                        
                        NavigationLink(destination: company(), label:{ TrainingCardView ( image:"com1", size: 120)}
                        )
                        .position(x: 300, y:-220)
                        ZStack{
                            RoundedRectangle(cornerRadius: 50)
                                .fill(.white)
                                .frame(width: 330, height: 140)
                                .padding(.leading, 60)
                                .position(x:150, y:-210)
                            Text("تقدم شركة الخطوط ")
                                .position(x:140, y:-220)
                            Text("السعودية للتموين لجميع... ")
                                .position(x:130, y:-190)
                            
                        }
                        NavigationLink(destination: company(), label:{ TrainingCardView ( image:"com3", size: 120)}
                        )
                        .position(x: 300, y:-360)
                        
                        ZStack{
                            
                            RoundedRectangle(cornerRadius: 50)
                                .fill(.white)
                                .frame(width: 330, height: 140)
                                .padding(.leading, 60)
                                .position(x:150, y:-350)
                            Text("نمنح موظفينا الفرصة ")
                                .position(x:140, y:-370)
                            Text(" الفرصة للقيام بالأعمال...")
                                .position(x:130, y:-340)
                         
                        }
                        NavigationLink(destination: company(), label:{ TrainingCardView ( image:"com4", size: 120)}
                        )
                        .position(x: 300, y:-500)
                    }
                }
          //  }
        }
    }
    struct companies_Previews: PreviewProvider {
        static var previews: some View {
            companies()
        }
    }
    struct TrainingCardView: View {
        //var title: String
        var image: String
        let size: CGFloat
        
        var body: some View {
            VStack{
                // Image("train_1")
                Image(image)
                    .resizable()
                    .frame(width: 150, height: 150 * (size/210))
                //.cornerRadius(20.0)
               // Text(title)
                //    .font(.title3)
                  //  .fontWeight(.bold)
              
            }
            .frame(width: 129, height: 140)
            .padding()
            .background(Color("Color1"))
            .cornerRadius(30)
            
        }
    }
    
    
}

