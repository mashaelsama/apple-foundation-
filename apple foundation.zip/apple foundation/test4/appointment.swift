
//  appointment.swift
//  test4
//  Created by Afrah Saleh on 03/07/1444 AH.
import SwiftUI
struct appointment: View {
    init() {
           UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.white]
           UINavigationBar.appearance().titleTextAttributes = [.foregroundColor: UIColor.black]
       }
    @State private var showingAlert = false
    @State var present = false

    var body: some View {
        NavigationView {
            ZStack {
                Color("Color")
                    .ignoresSafeArea()
                    .navigationTitle("مواعيدي")
                ScrollView{
                    VStack {
                        
                        Text("مواعيدي القادمة:")
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundColor(Color.white)
                            .padding(.leading,130)
                        
                            .padding(.bottom, -20)
                        Spacer()
                            .padding(.bottom)
                        ZStack{
                            RoundedRectangle(cornerRadius: 30)
                                .fill(.white)
                                .frame(width: 350, height: 240)
                                .padding(.leading, 5)
                            // .padding(.top, 5)
                            // .padding(.to)
                            
                            //.position(x:160, y:70)
                            VStack{
                                Text("بيانات الموعد:")
                                //  .padding(.bottom,10)
                                    .font(.title3)
                                    .fontWeight(.bold)
                                    .foregroundColor(Color("Color"))
                                    .multilineTextAlignment(.center)
                                    .padding(.leading, -125)
                                    .padding(.top,-25)
                                Text("التاريخ: ١٣/٢/٢٠٢٣")
                                    .padding(.leading, -120)
                                    .padding(.top,-5)
                                Text("الوقت: ٥ مساء")
                                    .padding(.leading, -120)
                                    .padding(.top,-5)
                                Text("نوع الأستشاره:")
                                    .padding(.leading, -120)
                                    .padding(.top,-5)
                                HStack{
                                    
                                    Button("محادثة") {
                                        showingAlert = true
                                     
                                    
                                       }
                                    
                                       .alert(isPresented: $showingAlert) {
                
                                           Alert(
                                               title: Text("تم تحديد نوع المحادثة"),
                                               message: Text("الرجاء الالتزام بالتوقيت حيث سيتواصل معك " + "استشاري عن طريق المحادثة المطلوبة"),
                                               dismissButton:.default(Text("حسنا"))
                                               
                                           )
                                           
                                       }
                                    
                                    .accentColor(.white)
                                    .padding()
                                    .background(Color("Color"))
                                    .cornerRadius(10)
                                    .padding(.leading,-155)
                                
                                    Button("إتصال   ") {
                                        showingAlert = true
                                       }
                                      
                                    .accentColor(.white)
                                    .padding()
                                    .background(Color("Color"))
                                    .cornerRadius(10)
                                    .padding(.leading,-80)
                                }
                                
                                }
                         
                        }
                        AppoinCardView (title: "د. محمد سالم", image:"train_1", size: 120)
                            .position(x: 280, y:-120)
                        
                        Text("مواعيدي السابقة:")
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundColor(Color.white)
                            .position(x:270, y:-130)
                        Spacer()
                            .padding(.bottom)
                        ZStack{
                            RoundedRectangle(cornerRadius: 30)
                                .fill(.white.opacity(0.7))
                                .frame(width: 350, height: 200)
                                .padding(.leading, 70)
                                .position(x:160, y:-70)
                                
                            VStack{
                                Text("بيانات الموعد:")
                                //  .padding(.bottom,10)
                                    .font(.title3)
                                    .fontWeight(.bold)
                                    .foregroundColor(Color("Color"))
                                    .multilineTextAlignment(.center)
                                    .padding(.leading, -125)
                                    .padding(.top,-210)
                                Text("التاريخ: ١٣/٢/٢٠٢٣")
                                    .padding(.leading, -120)
                                    .padding(.top,-185)
                                Text("الوقت: ٥ مساء")
                                    .padding(.leading, -120)
                                    .padding(.top,-170)
                                Text("نوع الأستشاره:")
                                    .padding(.leading, -120)
                                    .padding(.top,-155)
                                
                            }
                        }
                        AppoinCardView (title: "د. محمد سالم", image:"train_1", size: 120)
                            .position(x: 280, y:-290)
                            .opacity(0.5)
                        
                        ZStack{
                            RoundedRectangle(cornerRadius: 30)
                                .fill(.white.opacity(0.7))
                                .frame(width: 350, height: 200)
                                .padding(.leading, 90)
                                .position(x:150, y:-210)
                            VStack{
                                Text("بيانات الموعد:")
                                //  .padding(.bottom,10)
                                    .font(.title3)
                                    .fontWeight(.bold)
                                    .foregroundColor(Color("Color"))
                                    .multilineTextAlignment(.center)
                                    .padding(.leading, -125)
                                    .padding(.top,-350)
                                Text("التاريخ: ١٣/٢/٢٠٢٣")
                                    .padding(.leading, -120)
                                    .padding(.top,-335)
                                Text("الوقت: ٥ مساء")
                                    .padding(.leading, -120)
                                    .padding(.top,-325)
                                Text("نوع الأستشاره:")
                                    .padding(.leading, -120)
                                    .padding(.top,-310)
                            }
                            
                            AppoinCardView (title: "د. محمد سالم", image:"train_3", size: 120)
                                .opacity(0.5)
                                .position(x: 280, y:-210)
                                
                            
                        }
                    }
                    
                }
            }
        }}
        

    struct appointment_Previews: PreviewProvider {
        static var previews: some View {
            appointment()
        }
    }
    struct AppoinCardView: View {
        var title: String
        var image: String
        let size: CGFloat
        
        var body: some View {
            VStack{
                // Image("train_1")
                Image(image)
                    .resizable()
                
                    .frame(width: 120, height: 150 * (size/210))
                //.cornerRadius(20.0)
                Text(title)
                    .font(.title3)
                    .fontWeight(.bold)
              
            }
            .frame(width: 129, height: 120)
            .padding()
            .background(.clear)
            .cornerRadius(30)
            
        }
    }
    
    
}



