//
//  ContentView.swift
//  test4
//
//  Created by Afrah Saleh on 02/07/1444 AH.
//

import SwiftUI

struct ContentView: View {
    
    init() {
        UITabBar.appearance().backgroundColor =
        UIColor(named: "b")
       UITabBar.appearance().unselectedItemTintColor = UIColor(named: "i")
        
    }
    var body: some View {
        ZStack{
            //NavigationView {
                TabView {
                    
                    explore()
                        .tabItem {
                            Label("إكتشف", systemImage: "square.grid.2x2")
                        }
                    appointment()
                        .badge(1)
                        .tabItem {
                            Label("مواعيدي", systemImage: "calendar.badge.clock")
                        }
                    profile()
                        .tabItem {
                            Label("حسابي", systemImage: "person.crop.circle")
                        }
                }
                //.navigationTitle("explore")
                .accentColor(.white)
                
            }}
        
        
  // }
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
}
