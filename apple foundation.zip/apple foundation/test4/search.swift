//
//  search.swift
//  test4
//
//  Created by amjad alqhtani  on 03/07/1444 AH.
//

import SwiftUI

struct search: View {
    @State var searchText = ""
    
    var body: some View {
        NavigationView{
             
            VStack{
                List{
                    Text("Hello")
                }
                .searchable(text: $searchText)
                
            }
            
        }
    }
}
    
    struct search_Previews: PreviewProvider {
        static var previews: some View {
            search()
        }
    }

