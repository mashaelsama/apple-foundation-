//
//  company.swift
//  test4
//
//  Created by Afrah Saleh on 06/07/1444 AH.
//

import SwiftUI

struct company: View {
    @State var isDragging = false
    @State var position = CGSize.zero
    @State var present = false

    init() {
        //Use this if NavigationBarTitle is with Large Font
     
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.white]
     
     
//           //Use this if NavigationBarTitle is with displayMode = .inline
//           UINavigationBar.appearance().titleTextAttributes = [.foregroundColor: UIColor.white]
        
        
    }
    
    var body: some View {
       // NavigationView {
            ZStack {
                Color("Color")
                    .ignoresSafeArea()
                    .navigationTitle("تقديم الشركات")
                    .navigationBarTitleDisplayMode(.inline)
                ScrollView {
                    Spacer()
                    VStack{
                        RoundedRectangle(cornerRadius: 40,
                                         style: .continuous)
                        .foregroundColor(Color("u"))
                        .frame(width: 400, height: 120)
                        .padding(.leading,-100)
                        .padding(.top,20)
                        
                        RoundedRectangle(cornerRadius: 40,
                                         style: .continuous)
                        .foregroundColor(Color("y"))
                        .frame(width: 400, height: 120)
                        .padding(.leading,-140)
                        .padding(.top,-128)
                        
                        RoundedRectangle(cornerRadius: 40,
                                         style: .continuous)
                        .foregroundColor(Color.white)
                        .frame(width: 400, height: 120)
                        .padding(.leading,-180)
                        .padding(.top,-135)
                        Image("com3")
                            .padding(.leading,-150)
                            .padding(.top,-180)

                        ZStack{
                            
                            RoundedRectangle(cornerRadius: 30,
                                             style: .continuous)
                            .foregroundColor(Color.white)
                            .frame(width: 307, height: 180)
                            .padding(.leading,130)
                            .padding(.top,0)
                            
                            Text("ماذا تقدم؟")
                                .fontWeight(.bold)
                                .padding(.leading,120)
                                .padding(.top,-60)

                            Text("تقدم شركة الخطوط السعودية للتموين")
                                .padding(.leading,115)
                                .padding(.top,-30)
                            
                            Text("لجميع موظفيها الفرصة للتطور على")
                                .padding(.leading,115)
                                .padding(.top,5)
                            
                            Text("الصعيدي، الشخصي والمهني من خلال")
                                .padding(.leading,118)
                                .padding(.top,50)
                            
                            Text("تحدي قدراتهم.")
                                .padding(.leading,120)
                                .padding(.top,100)
                            
                            
                        }
                        
                        
                        
                        ZStack{
                            RoundedRectangle(cornerRadius: 30,
                                             style: .continuous)
                            .foregroundColor(Color.white)
                            .frame(width: 307, height: 180)
                            .padding(.leading,-120)
                            .padding(.top,0)
                            
                            Text("ماذا تتيح؟")
                                .fontWeight(.bold)
                                .padding(.leading,-100)
                                .padding(.top,-65)

                            Text("ابراز مهاراتهم ومكافآتهم على تفوقهم,")
                                .padding(.leading,-105)
                                .padding(.top,-35)
                            
                            Text("تتاح جميع هذه الفرص في بيئة تعاونية")
                                .padding(.leading,-105)
                                .padding(.top,-5)
                            
                            Text("تشجع على معرفة خدماتنا ومنتجاتنا")
                                .padding(.leading,-105)
                                .padding(.top,40)
                            
                            Text("ميقينين بأهمية تقديم الافضل لكافة")
                                .padding(.leading,-105)
                                .padding(.top,85)
                            
                            Text("شركائنا.")
                                .multilineTextAlignment(.center)
                                .padding(.leading,-80)
                                .padding(.top,125)
                        }
                        
                        Button("تقديم") {
                            present = true
                         
                        }
                    
                        .buttonStyle(.bordered)
                        .accentColor(.white)
                        .background(Color("Color7"))
                        .cornerRadius(10)
                        .padding(.leading,0)
                        .padding(.top,20)
                        NavigationLink(destination: company2(), isActive: $present, label: {
                            
                        })
                    }
                    
              //  }
                
              
            }}}
    
    struct company_Previews: PreviewProvider {
        static var previews: some View {
            company()
        }
    }
}
