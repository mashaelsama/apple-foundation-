//
//  explore.swift
//  test4
//
//  Created by Afrah Saleh on 03/07/1444 AH.
//

import SwiftUI

struct explore: View {
    init() {
        //Use this if NavigationBarTitle is with Large Font
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        //Use this if NavigationBarTitle is with displayMode = .inline
        UINavigationBar.appearance().titleTextAttributes = [.foregroundColor: UIColor.black]
    }
   

    
    @State var searchText = ""
    @State var selected = 1
    
    var body: some View {
        NavigationView {
            ZStack {
                Color("Color")
                    .ignoresSafeArea()
                    .navigationTitle("إكتشف")
                
                ScrollView {
                    VStack{
                    
                        Picker(selection: $selected, label:Text("picker"), content: {
                            Text("شركات ")
                                .tag(1)
                            Text("استشاريين")
                                .tag(2)
                               // .padding(.top,800)
                                                
                            
                        })
                        .pickerStyle(SegmentedPickerStyle())
                       // .padding(.bottom,630)
              
                .searchable(text: $searchText)
                }
                    
                    Spacer()
                    
                    ZStack{
                        Text("التدريب التعاوني")
                            .font(.headline)
                            .fontWeight(.bold)
                            .foregroundColor(Color.white)
                            .padding(.top, -110)
                        //.padding(.top)
                            .multilineTextAlignment(.trailing)
                            .padding(.leading, 230.0)
                            .frame(width: 400, height: 230)
                            .background(Color("Color2").opacity(0.5))
                            .cornerRadius(30)
                        NavigationLink(destination: companies(), label: {
                            Text("مشاهدة الكل ")
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .position(x: 70, y: 15)
                        })
                        ScrollView (.horizontal, showsIndicators: false){
                            HStack (spacing: 30 ){
                                Spacer()
                                NavigationLink(destination: company(), label:{ CompanyCardView (title: "", image:"com1", size: 150)}
                                )
                                NavigationLink(destination: company(), label:{ CompanyCardView (title: "", image:"com2", size: 150)})
                                NavigationLink(destination: company(), label:{ CompanyCardView (title: "", image: "com3", size: 150)}
                                )
                            }
                            .foregroundColor(.black)}
                    }
                    ZStack{
                        Text(" الإستشاريين")
                            .font(.headline)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .multilineTextAlignment(.trailing)
                            .padding(.leading, 250)
                            .padding(.top,-135)
                            .frame(width: 400, height: 280)
                            .background(Color("Color2").opacity(0.5))
                            .cornerRadius(30)
                        NavigationLink(destination: training(), label: {
                            Text("مشاهدة الكل ")
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .position(x: 70, y: 15)
                        })
                        ScrollView (.horizontal, showsIndicators: false){
                            
                            HStack (spacing: 30 ){
                                Spacer()
                                NavigationLink(destination: appointmentApply(), label:{ TrainingCardView (title: "د. محمد سالم", image:"train_1", size: 150)}
                                )
                                NavigationLink(destination: appointmentApply(), label:{ TrainingCardView (title: "آ.د. ساره علي", image:"train_2", size: 150)})
                                NavigationLink(destination: appointmentApply(), label:{ TrainingCardView (title: "آ. نوره احمد ", image: "train_3", size: 150)}
                                )
                                Spacer()
                            }
                            .foregroundColor(.black)}
                    }
                    .padding(.top)
                }
                
                
            }}
        
    }}
   
    struct explore_Previews: PreviewProvider {
        static var previews: some View {
            explore()
        }
    }


//method for the card view
struct TrainingCardView: View {
    var title: String
    var image: String
    let size: CGFloat
    
    var body: some View {
        VStack{
           // Image("train_1")
            Image(image)
                .resizable()
                .frame(width: size, height: 150 * (size/200))
            //.cornerRadius(20.0)
            Text(title)
                .font(.title3)
                .fontWeight(.bold)
            HStack (spacing: 2){
                ForEach(0 ..< 5){ item in
                    Image("star")
                        .offset(x: 45)
                }
                Spacer()
            }
           
        }
        .frame(width: size)
        .padding()
        .background(Color("Color1"))
        .cornerRadius(30)
    }
}


struct CompanyCardView: View {
    var title: String
    var image: String
    let size: CGFloat
    
    var body: some View {
        VStack{
            Image(image)
                .resizable()
                .frame(width: size, height: 150 * (size/220))
            Text(title)
                .font(.title3)
                .fontWeight(.bold)
        }
        .frame(width: size)
        .padding()
        .background(Color("Color1"))
        .cornerRadius(30)
      
    }
}
